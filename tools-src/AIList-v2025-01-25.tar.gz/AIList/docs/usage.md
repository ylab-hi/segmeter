# Usage reference


Here you can see the command-line usage instructions for the main command and for each subcommand:


`/home/nsheff/code//AIList/bin/AIList --help`
```
input error: data file (.bed), query file (.bed), option (-L coverage length) 
```
