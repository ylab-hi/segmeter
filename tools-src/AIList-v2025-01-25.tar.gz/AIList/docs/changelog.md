# Changelog

## v0.1 (*Unreleased*)

Added:

  - First semi-functional release.


