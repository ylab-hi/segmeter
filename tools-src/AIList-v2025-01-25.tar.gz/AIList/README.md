# Augmented Interval List: a novel data structure for efficient genomic interval search

Complete documentation can be found at [http://code.databio.org/AIList/](http://code.databio.org/AIList/).
